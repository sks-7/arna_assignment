package tests

import (
	"task-manager/internal/utils"
	"testing"
)

func TestValidateTask(t *testing.T) {

	err := utils.ValidateTask("", "todo")

	if err == nil {
		t.Errorf("expected error for empty title")
	}
}
