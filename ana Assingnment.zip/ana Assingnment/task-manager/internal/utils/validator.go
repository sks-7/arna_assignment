package utils

import "errors"

func ValidateTask(title string, status string) error {

	if title == "" {
		return errors.New("title is required")
	}

	if len(title) > 200 {
		return errors.New("title must be less than 200 characters")
	}

	valid := map[string]bool{
		"todo":        true,
		"in_progress": true,
		"done":        true,
	}

	if status != "" && !valid[status] {
		return errors.New("status must be todo, in_progress, or done")
	}

	return nil
}
