package handlers

import (
	"net/http"
	"task-manager/internal/dto"
	"task-manager/internal/logger"
	"task-manager/internal/service"

	"github.com/gin-gonic/gin"
)

type TaskHandler struct {
	service *service.TaskService
}

func NewTaskHandler(s *service.TaskService) *TaskHandler {
	return &TaskHandler{service: s}
}
func (h *TaskHandler) CreateTask(c *gin.Context) {

	logger.Log.Info("CreateTask API called")

	var req dto.CreateTaskRequest

	if err := c.ShouldBindJSON(&req); err != nil {

		logger.Log.Error("Validation failed: ", err)

		c.JSON(http.StatusBadRequest, gin.H{
			"error": err.Error(),
		})
		return
	}

	task, err := h.service.CreateTask(req.Title, req.Status)

	if err != nil {

		logger.Log.Error("Task creation failed",err)

		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "failed to create task",
		})
		return
	}

	resp := dto.TaskResponse{
		ID:     task.ID,
		Title:  task.Title,
		Status: task.Status,
	}

	c.JSON(http.StatusCreated, resp)
}

func (h *TaskHandler) ListTasks(c *gin.Context) {

	logger.Log.Info("ListTasks API called")

	tasks, err := h.service.ListTasks()

	if err != nil {

		logger.Log.Error("Fetching tasks failed")

		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "failed to fetch tasks",
		})
		return
	}

	logger.Log.Info("Tasks fetched successfully")

	c.JSON(http.StatusOK, tasks)
}
