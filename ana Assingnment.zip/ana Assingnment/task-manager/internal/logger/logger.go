package logger

import (
	"os"

	log "github.com/sirupsen/logrus"
)

var Log *log.Logger

func InitLogger() *log.Logger {

	Log = log.New()

	err := os.MkdirAll("logs", os.ModePerm)
	if err != nil {
		log.Fatal("Failed to create logs directory:", err)
	}

	file, err := os.OpenFile("logs/app.log", os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666)
	if err != nil {
		log.Fatal("Failed to open log file:", err)
	}

	Log.SetOutput(file)
	Log.SetFormatter(&log.JSONFormatter{})
	Log.SetLevel(log.InfoLevel)

	return Log
}
