package repository

import (
	"encoding/json"
	"os"
	"path/filepath"
	"task-manager/internal/models"
)

type TaskRepository struct {
	FilePath string
}

func NewTaskRepository(path string) *TaskRepository {

	dir := filepath.Dir(path)
	os.MkdirAll(dir, os.ModePerm)

	if _, err := os.Stat(path); os.IsNotExist(err) {
		os.WriteFile(path, []byte("[]"), 0644)
	}

	return &TaskRepository{
		FilePath: path,
	}
}

func (r *TaskRepository) GetTasks() ([]models.Task, error) {

	var tasks []models.Task

	file, err := os.ReadFile(r.FilePath)
	if err != nil {
		return tasks, err
	}

	json.Unmarshal(file, &tasks)

	return tasks, nil
}

func (r *TaskRepository) SaveTasks(tasks []models.Task) error {

	data, err := json.MarshalIndent(tasks, "", " ")
	if err != nil {
		return err
	}

	return os.WriteFile(r.FilePath, data, 0644)
}
