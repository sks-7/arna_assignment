package service

import (
	"fmt"
	"strings"
	"task-manager/internal/models"
	"task-manager/internal/repository"

	"github.com/google/uuid"
)

type TaskService struct {
	repo *repository.TaskRepository
}

func NewTaskService(repo *repository.TaskRepository) *TaskService {
	return &TaskService{repo: repo}
}

func (s *TaskService) CreateTask(title string, status string) (models.Task, error) {

	tasks, err := s.repo.GetTasks()
	if err != nil {
		return models.Task{}, err
	}

	for _, t := range tasks {
		if strings.EqualFold(t.Title, title) {
			return models.Task{}, fmt.Errorf("task already exists")
		}
	}

	if status == "" {
		status = "todo"
	}

	task := models.Task{
		ID:     uuid.New().String(),
		Title:  title,
		Status: status,
	}

	tasks = append(tasks, task)

	err = s.repo.SaveTasks(tasks)
	if err != nil {
		return models.Task{}, err
	}

	return task, nil
}

func (s *TaskService) ListTasks() ([]models.Task, error) {
	return s.repo.GetTasks()
}
