package dto

type CreateTaskRequest struct {
	Title  string `json:"title" binding:"required,max=200"`
	Status string `json:"status,omitempty" binding:"omitempty,oneof=todo in_progress done"`
}

type TaskResponse struct {
	ID     string `json:"id"`
	Title  string `json:"title"`
	Status string `json:"status"`
}
