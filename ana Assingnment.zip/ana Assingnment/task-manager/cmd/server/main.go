package main

import (
	"task-manager/internal/handlers"
	"task-manager/internal/logger"
	"task-manager/internal/repository"
	"task-manager/internal/service"

	"github.com/gin-gonic/gin"
)

func main() {

	log := logger.InitLogger()
	log.Info("Server starting...")

	router := gin.Default()
	router.Use(logger.RequestLogger())

	repo := repository.NewTaskRepository("../../storage/tasks.json")
	service := service.NewTaskService(repo)
	handler := handlers.NewTaskHandler(service)

	router.POST("/tasks", handler.CreateTask)
	router.GET("/tasks", handler.ListTasks)

	log.Info("Server running on port 8080")

	router.Run(":8080")
}
